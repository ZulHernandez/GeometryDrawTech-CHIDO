package proyecto;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class wproblemas extends JFrame implements ActionListener
{
    JButton bot1;
    JButton bot2;
    JButton bot3;
    JButton bot4;
    JButton bot5;
    JLabel lab1;
    JLabel lab2;
    JTextField tex1;
    JTextField tex2;
    Dimension pant;

    public wproblemas(int bot)
    {
        Color ZUL = new Color (41,103,159);
        
        pant = Toolkit.getDefaultToolkit().getScreenSize();
        int width = (int)pant.getWidth();
        int height = (int)pant.getHeight();
                
        setLayout (null);
        setSize (1300,700);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo (null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        this.getContentPane().setBackground(Color.white);
        
        System.out.println(height);
        System.out.println(width);
        
        ImageIcon home =new ImageIcon("/Imgs/Menu.JPG");
        ImageIcon rev =new ImageIcon("/Imgs/Atraso.JPG");
        ImageIcon ade =new ImageIcon("/Imgs/Adelanto.JPG");
        ImageIcon re =new ImageIcon("/Imgs/Refresca.JPG");
        ImageIcon lis =new ImageIcon("/Imgs/Lista.JPG");
                
        lab1 = new JLabel("AQUI VA EL GIF");
        lab1.setBounds(width/15 + 20,5*height/27,300,300);
        add (lab1);
        
        tex2 = new JTextField();
        tex2.setBounds(width/15,5*height/27,400,400);
        add (tex2);
        tex2.setBackground(ZUL.brighter());
        
        lab2 = new JLabel("<html>1.-Trazar una recta AB<br>2.-trazar una semirecta que parta de cualquier punta de A o B<br>3.- Abrir el compas a cualquier distancia<br>4.-dividir la semirecta en las partes que quieran<br>5.- Hacer perpendiculares desde la semirecta<br>6.- Listo!!!!!<html>");
        lab2.setBounds(width/2 + 20,height/27,600,500);
        add (lab2);
        lab2.setForeground(Color.WHITE);
        lab2.setFont(new java.awt.Font("SHOWCARD GOTHIC",Font.PLAIN,25));
        lab2.setHorizontalAlignment(SwingConstants.CENTER);
        lab2.setVerticalAlignment(SwingConstants.CENTER);
        
        tex1 = new JTextField();
        tex1.setBounds(width/2,height/27,600,500);
        add (tex1);
        tex1.setBackground(ZUL.brighter());
        
        bot1 = new JButton();
        bot1.setBounds(width/15,height/27,60,60);
        add(bot1);
        bot1.addActionListener(this);
        bot1.setIcon(home);
        
        bot2 = new JButton();
        bot2.setBounds(8*width/15,21*height/27,60,60);
        add(bot2);
        bot2.addActionListener(this);
        bot2.setIcon(re);
        
        bot3 = new JButton();
        bot3.setBounds(9*width/15,21*height/27,60,60);
        add(bot3);
        bot3.addActionListener(this);
        bot3.setIcon(rev);
        
        bot4 = new JButton();
        bot4.setBounds(10*width/15,21*height/27,60,60);
        add(bot4);
        bot4.addActionListener(this);
        bot4.setIcon(ade);
        
        bot5 = new JButton();
        bot5.setBounds(11*width/15,21*height/27,60,60);
        add(bot5);
        bot5.addActionListener(this);
        bot5.setIcon(lis);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }


}

