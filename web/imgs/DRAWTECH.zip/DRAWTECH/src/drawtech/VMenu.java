
package drawtech;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VMenu extends JFrame implements ActionListener {

    JLabel logoM;
    JLabel logoD;
    JLabel titulo;
    JLabel gif;
    JButton problemas;
    JButton creditos;
    JButton salir;
   // Dimension pantalla;
    JLabel texto;
    String tipoLetra;
    Color ZUL;
    int width;
    int height;
    public VMenu(Color colorGral){
         
     setLayout(null);   
     setSize(1300,700);
     setLocationRelativeTo(null);
     setVisible(true);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setExtendedState(JFrame.MAXIMIZED_BOTH);
     this.getContentPane().setBackground(Color.white);
    
     
     //Asignación del color desde la clase cConfiguracion
     cConfiguracion config = new cConfiguracion(colorGral);
     ZUL=config.getZUL();
     tipoLetra=config.getTipoLetra();   
     width=config.getWidth();
     height=config.getHeight();  
       cImagen imag= new cImagen(width,height);
     //Label donde se coloca el logo de marsoft
     ImageIcon newi3=imag.obtenerImagen("/Imgs/Marsoft.jpg",8,8);
     logoM=new JLabel(newi3);
     logoM.setBounds(width/8,height/20,width/8,height/8);
     add(logoM);
     
     //Logo de DrawTech
     ImageIcon newd1=imag.obtenerImagen("/Imgs/DrawTech.jpg",8,8);
     //Label donde se pone logo de DrawTech
     logoD=new JLabel(newd1);
     logoD.setBounds(width/4*3,height/20,width/8,height/8);
     add(logoD);
     
     titulo=new JLabel("Geometry DrawTech");
     titulo.setBounds(width/4,height/20,width/2,height/8);
     add(titulo);
     titulo.setHorizontalAlignment(SwingConstants.CENTER);
      titulo.setVerticalAlignment(SwingConstants.CENTER);
     titulo.setFont(new java.awt.Font(tipoLetra, 0,height/18));
    
     
     problemas=new JButton("Problemas");
     problemas.setBounds(width/8,height/4,width/4,height/16);
     add(problemas);
     problemas.addActionListener(this);
     problemas.setFont(new java.awt.Font(tipoLetra,0,height/32));
     problemas.setBackground(ZUL);
     problemas.setForeground(Color.white);
     
     creditos=new JButton("Creditos");
     creditos.setBounds(width/8,height/4*2,width/4,height/16);
     add(creditos);
     creditos.addActionListener(this);
     creditos.setFont(new java.awt.Font(tipoLetra,0,height/32));
     creditos.setBackground(ZUL);
     creditos.setForeground(Color.white);

     salir=new JButton("Salir");
     salir.setBounds(width/8,height/4*3,width/4,height/16);
     add(salir);
     salir.addActionListener(this);
     salir.setFont(new java.awt.Font(tipoLetra,0,height/32));
     salir.setBackground(ZUL);
     salir.setForeground(Color.white);
     
     ImageIcon g=new ImageIcon(getClass().getResource("/Imgs/GifMenu.gif"));  
     gif=new JLabel(g);
     g.setImageObserver(gif);
     gif.setBounds(width/2+width/8,height/4,300,200);
     add(gif);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getActionCommand().equals("Problemas")){
         dispose();   
         VLista w1=new VLista(ZUL);
        }
        if(e.getActionCommand().equals("Creditos")){
         dispose();   
         VCreditos w2=new VCreditos(ZUL);
        }
        if(e.getActionCommand().equals("Salir")){
        
         VSalir w3=new VSalir(ZUL);
        
        }
    }
    
    
}
