package drawtech;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javafx.scene.layout.Border;
import javax.swing.*;

public class wproblemas extends JFrame implements ActionListener
{
    JButton Menu;
    JButton Atras;
    JButton Adelantar;
    JButton Refrescar;
    JButton Lista;
    JLabel lab1;
    JLabel lab2;
    JTextField tex1;
    JLabel paso;
    Color ZUL;
    public String descrip1;
    String imgsp1[]=new String [5];
    int i=0;
    int width;
    int height;
    String tipoLetra;
    //mediante el constructor
    //asignarle el texto y el gif correspondiente usando ese mismo numero que trae el int problem
    //para saber que problema se selecciono
    public wproblemas(int problem,Color nColor)
    {
        cConfiguracion config=new cConfiguracion(nColor);
        imgsp1=config.getVentanaProblemas(problem);
        ZUL= config.getZUL();      
        width = config.getWidth();
        height = config.getHeight();
        descrip1=config.getDescripcionProblem();
        tipoLetra=config.getTipoLetra();
        
        cImagen imag=new cImagen(width,height);
        
        setLayout (null);
        setSize (1300,700);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo (null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        this.getContentPane().setBackground(Color.white);
   
                
         ImageIcon g1=new ImageIcon(getClass().getResource(imgsp1[0]));
         ImageIcon g2=new ImageIcon(getClass().getResource(imgsp1[1]));
         ImageIcon g3=new ImageIcon(getClass().getResource(imgsp1[2]));
         ImageIcon g4=new ImageIcon(getClass().getResource(imgsp1[3]));
         ImageIcon g5=new ImageIcon(getClass().getResource(imgsp1[4]));
        
        lab1 = new JLabel(g1);
        g1.setImageObserver(lab1);
        System.out.println(g1.getIconWidth());
        System.out.println(g1.getIconHeight());
        System.out.println();
        //30,27
        lab1.setBounds(width/30,5*height/27,500,400);
        add (lab1);
        lab1.setForeground(Color.WHITE);
        lab1.setBackground(Color.WHITE);
        lab1.setFont(new java.awt.Font(tipoLetra,Font.ROMAN_BASELINE,height/12));
        lab1.setHorizontalAlignment(SwingConstants.CENTER);
        lab1.setVerticalAlignment(SwingConstants.CENTER);
        
        paso=new JLabel("Paso "+(i+1));
        paso.setBounds(width/30,20*height/27,width/3,height/9);
        add(paso);
        paso.setForeground(ZUL);
        paso.setFont(new java.awt.Font(tipoLetra,0,height/18));
        paso.setHorizontalAlignment(SwingConstants.CENTER);
        paso.setVerticalAlignment(SwingConstants.CENTER);
        //Label y texto del gif
        /*tex2 = new JTextField();
        tex2.setBounds(width/30,5*height/27,width/3,height/3);
        add (tex2);
        tex2.setBackground(ZUL);
        tex2.setEnabled(false);*/
        
        lab2 = new JLabel(descrip1);
        lab2.setBounds(width/32*15,5*height/27,width/2,height/2);
        add (lab2);
        lab2.setForeground(Color.WHITE);
        lab2.setFont(new java.awt.Font(tipoLetra,Font.CENTER_BASELINE,height/2/29));
        lab2.setHorizontalAlignment(SwingConstants.CENTER);
        lab2.setVerticalAlignment(SwingConstants.CENTER);
        //texto de la descripcion
        tex1 = new JTextField();
        tex1.setBounds(width/32*15,5*height/27,width/2,height/2);
        add (tex1);
        tex1.setBackground(ZUL);
        tex1.setEnabled(false);
        //Imagen menu que va en el boton bot1
        
        ImageIcon h1=imag.obtenerImagenNreduc("/Imgs/Menu.JPG",75,75);
        
        Menu = new JButton(h1);
        Menu.setBounds(width/30,height/27,75,75);
        add(Menu);
        Menu.addActionListener(this);
        
        //Imagen de atraso que va en el boton bot2
        ImageIcon newr=imag.obtenerImagenNreduc("/Imgs/Atraso.JPG",75,75);
        
        Atras = new JButton(newr);
        Atras.setBounds(16*width/32,20*height/27,75,75);
        add(Atras);
        Atras.addActionListener(this);
        Atras.setEnabled(false);
        
        //Imagen de adelanto que va en el boton bot3
        ImageIcon newa=imag.obtenerImagenNreduc("/Imgs/Adelanto.JPG",75,75);
        
        Adelantar = new JButton(newa);
        Adelantar.setBounds(20*width/32,20*height/27,75,75);
        add(Adelantar);
        Adelantar.addActionListener(this);
        
        //Imagen de refrescar que va en el boton bot4
        ImageIcon newR=imag.obtenerImagenNreduc("/Imgs/Refresca.JPG",75,75);
        
        Refrescar = new JButton(newR);
        Refrescar.setBounds(24*width/32,20*height/27,75,75);
        add(Refrescar);
        Refrescar.addActionListener(this);
        
        //Imagen de lista que va en el botom bot5
        ImageIcon newL=imag.obtenerImagenNreduc("/Imgs/Lista.JPG",75,75);
        
        Lista = new JButton(newL);
        Lista.setBounds(28*width/32,20*height/27,75,75);
        add(Lista);
        Lista.addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(Menu)){
            dispose();
         VMenu m=new VMenu(ZUL);   
         
        }
        if(e.getSource().equals(Lista)){
            dispose();
           VLista v=new VLista(ZUL);           
        }
        if(e.getSource().equals(Adelantar)){
          if(i<4){
          ImageIcon g2=new ImageIcon(getClass().getResource(imgsp1[i+=1]));
          lab1.setIcon(g2); 
          paso.setText("Paso "+(i+1));
          }
          if(i==4)
           Adelantar.setEnabled(false);         
          if(i>0)
              Atras.setEnabled(true);
        }
        if(e.getSource().equals(Atras)){
         if(i>0){  
           ImageIcon g2=new ImageIcon(getClass().getResource(imgsp1[i-=1]));
             lab1.setIcon(g2);            
             paso.setText("Paso "+(i+1));
             if(i<4)
             Adelantar.setEnabled(true);
         }
         if(i==0)
             Atras.setEnabled(false);       
        }
        if(e.getSource().equals(Refrescar)){
            i=0;
         ImageIcon g2=new ImageIcon(getClass().getResource(imgsp1[i]));
         lab1.setIcon(g2);
         paso.setText("Paso "+(i+1));
         Adelantar.setEnabled(true);
         Atras.setEnabled(false);
        }
    }

    }

