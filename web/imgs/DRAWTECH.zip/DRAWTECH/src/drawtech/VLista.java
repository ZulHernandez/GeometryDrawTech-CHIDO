
package drawtech;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VLista extends JFrame implements ActionListener{
   JButton menu;
   JButton P1;
   JButton P2;
   JButton P3;
   JButton P4;
   JButton P5;
   JButton ir;
   JTextField descrip;
   JLabel descri;
   JLabel logoM;
   JLabel logoD;
   String des;
   String ves;
   String tipoLetra;
   int p;
   int width;
   int height;
   Color ZUL;
   cConfiguracion config;
   public VLista(Color nColor){
     p=0;
      
 setLayout(null);   
 setSize(1300,700);
 setLocationRelativeTo(null);
 setVisible(true);
 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 setExtendedState(JFrame.MAXIMIZED_BOTH);
 this.getContentPane().setBackground(Color.white);
 config=new cConfiguracion(nColor);
 width=config.getWidth();
 height=config.getHeight();
 ZUL=config.getZUL();
 tipoLetra=config.getTipoLetra();

 
 cImagen imag=new cImagen(width,height);
  //Imagen de "menu" 

 ImageIcon newimg=imag.obtenerImagenNreduc("/Imgs/Menu.JPG",75,75);
 //boton donde se coloca la imagen de "menu"
 menu=new JButton(newimg);
 menu.setBounds(width/14,height/10*8,75,75);
 add(menu);
 menu.addActionListener(this);
 
 //Logo de marsoft 
 
 ImageIcon newi3=imag.obtenerImagenNreduc("/Imgs/Marsoft.jpg",height/4,width/9);
 //Label donde se coloca el logo de marsoft
 logoM=new JLabel(newi3);
 logoM.setBounds(width/14,height/20,height/4,width/9);
 add(logoM);
//Logo de DrawTech

 ImageIcon newd1=imag.obtenerImagenNreduc("/Imgs/DrawTech.jpg",height/4,width/9);
 //Label donde se pone logo de DrawTech
 logoD=new JLabel(newd1);
 logoD.setBounds(height+height/4,height/20,height/4,width/9);
 add(logoD);
//Imagen de "ir" 
 
 ImageIcon newk1=imag.obtenerImagenNreduc("/Imgs/Ir.jpg",75,75);
 //Boton de ir donde se inserta imagen "ir"
 ir=new JButton(newk1);
 ir.setBounds(width/10*8+height/64,height/10*8,75,75);
 add(ir);
 ir.addActionListener(this);
 ir.setFont(new java.awt.Font(tipoLetra,0 , 15));
 ir.setHorizontalAlignment(SwingConstants.CENTER);
 ir.setVerticalAlignment(SwingConstants.CENTER);
 ir.setBackground(ZUL);
 ir.setForeground(Color.white);
 
 P1=new JButton("Poligonos de 'n' lados ");
 P1.setBounds(width/14,height/10*3,width/4,height/32);
 add(P1);
 P1.addActionListener(this);
 P1.setFont(new java.awt.Font(tipoLetra,0, height/64));
 P1.setBackground(ZUL);
 P1.setForeground(Color.white);
 
 P2=new JButton("Enlaces");
 P2.setBounds(width/14,height/10*4,width/4,height/32);
 add(P2);
 P2.addActionListener(this);
 P2.setFont(new java.awt.Font(tipoLetra,0 ,height/64));
 P2.setBackground(ZUL);
 P2.setForeground(Color.white);
 
 P3=new JButton("Elipse");
 P3.setBounds(width/14,height/10*5,width/4,height/32);
 add(P3);
 P3.addActionListener(this);
 P3.setFont(new java.awt.Font(tipoLetra,0, height/64));
 P3.setBackground(ZUL);
 P3.setForeground(Color.white);
 
 P4=new JButton("Parabolas");
 P4.setBounds(width/14,height/10*6,width/4,height/32);
 add(P4);
 P4.addActionListener(this);
 P4.setFont(new java.awt.Font(tipoLetra,0 , height/64));
 P4.setBackground(ZUL);
 P4.setForeground(Color.white);
 
 P5=new JButton("Division de una recta en 'n' partes iguales");
 P5.setBounds(width/14,height/10*7,width/4,height/32);
 add(P5);
 P5.addActionListener(this);
 P5.setFont(new java.awt.Font(tipoLetra,0 , height/64));
 P5.setBackground(ZUL);
 P5.setForeground(Color.white);
 
 descri=new JLabel();
 descri.setBounds(width/2,height/10*3,width/3,height/10*3);
 add(descri);
 descri.setForeground(Color.white);
 descri.setFont(new java.awt.Font(tipoLetra,0,height/10*3/18));
 descri.setVerticalAlignment(SwingConstants.CENTER);
 descri.setHorizontalAlignment(SwingConstants.CENTER);
 
 descrip=new JTextField();
 descrip.setBounds(width/2,height/10*3,width/3,height/10*3);
 add(descrip);
 descrip.setEnabled(false);
 descrip.setBackground(ZUL);
 descrip.setHorizontalAlignment(SwingConstants.CENTER);
 descrip.setForeground(Color.black);
 descrip.setFont(new java.awt.Font(tipoLetra,0,(height/10*3)/16));
 

 
   }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        clasesExtra.cConsultaProblema consult= new clasesExtra.cConsultaProblema();
        if(e.getSource().equals(menu)){
         dispose();   
         VMenu w1=new VMenu(ZUL);
        }
        if(e.getSource().equals(P1)){
         p=1;   
         descri.setText(config.descripProblemaLista(p));
        }
        if(e.getSource().equals(P2)){
         p=2;   
         descri.setText(config.descripProblemaLista(p));
        }
        if(e.getSource().equals(P3)){
         p=3;   
         descri.setText(config.descripProblemaLista(p));
        }
        if(e.getSource().equals(P4)){
         p=4;   
         descri.setText(config.descripProblemaLista(p));
        }
        if(e.getSource().equals(P5)){
         p=5;     
        descri.setText(config.descripProblemaLista(p));
        }
      if(e.getSource().equals(ir)){
          System.out.println(consult.aumentaConsulta(p));
          System.out.println("HOla");
          System.out.println(consult.getError());
          dispose();
          wproblemas w=new wproblemas(p,ZUL);   
         }
        
        
    }   
}
