
package drawtech;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class VPresenta extends JFrame implements ActionListener{
JLabel ImgPrin;
JLabel GIF;
JLabel slogan;
JButton carga;
int width;
int height;
Color ZUL;
String tipoLetra;
public VPresenta(){
    
    cConfiguracion config= new cConfiguracion();
  
  
    //setResizable(false);
    tipoLetra=config.getTipoLetra();
   ZUL= config.getZUL();
   width= config.getWidth();
   height=config.getHeight();

 cImagen imag= new cImagen(width,height);
 setLayout(null);   
 setSize(1300,700);
 setLocationRelativeTo(null);
 setVisible(true);
 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 setExtendedState(JFrame.MAXIMIZED_BOTH);
 this.getContentPane().setBackground(Color.white);
 
 ImageIcon newimg=imag.obtenerImagen("/Imgs/Marsoft.jpg",2,2);
 
 ImgPrin=new JLabel(newimg);
 ImgPrin.setBounds(width/4,height/10,width/2,height/2);
 add(ImgPrin);

 slogan=new JLabel("Un software tan amplio como el mar");
 slogan.setBounds(width/4,(height/8*6),width/2,100);
 add(slogan);
 slogan.setForeground(ZUL.brighter());
 slogan.setFont(new java.awt.Font(tipoLetra,Font.ITALIC , 25));
 slogan.setHorizontalAlignment(SwingConstants.CENTER);
 slogan.setVerticalAlignment(SwingConstants.CENTER);
 
 //GIF de cargando
 ImageIcon g=new ImageIcon(getClass().getResource("/Imgs/Cargando.gif"));

 GIF=new JLabel(g);
 g.setImageObserver(GIF);
 GIF.setBounds( (width/4*3),(height/8*6),122,122);
 add(GIF);
 GIF.setForeground(Color.red);
 GIF.setHorizontalAlignment(SwingConstants.CENTER);
 GIF.setVerticalAlignment(SwingConstants.CENTER);
 
 carga=new JButton("INICIAR");
 carga.setBounds((width/4*3),(height/8*6+122),175,50);
 add(carga);
 carga.addActionListener(this);
 carga.setForeground(ZUL);
 carga.setBackground(Color.white);
 carga.setHorizontalAlignment(SwingConstants.CENTER);
 carga.setVerticalAlignment(SwingConstants.CENTER);
 carga.setFont(new java.awt.Font(tipoLetra,0,20));
 
  System.out.println((width/8*3-width/8)+" "+(height/4+height/16)+"GIF MENU");
}  

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(carga)){
         dispose();   
          vPersonalizacion p=new vPersonalizacion();   
        }
    }
}
