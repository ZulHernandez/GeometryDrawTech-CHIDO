 
package drawtech;
public class DRAWTECH {

    public static void main(String[] args) {
       
         VPresenta g1=new VPresenta();
        //vPersonalizacion g1=new vPersonalizacion();
    }
    
}
