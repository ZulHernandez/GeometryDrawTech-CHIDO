
package drawtech;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class VCreditos extends JFrame implements ActionListener{
    
    JButton  menu;
    JTextField titulo;
    JLabel tit;
    int width;
    int height;
    Color ZUL;
    JLabel Creditos;
   String tipoLetra;
    public VCreditos(Color nColor){
     
     setLayout(null);   
     setSize(1300,700);
     setLocationRelativeTo(null);
     setVisible(true);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setExtendedState(JFrame.MAXIMIZED_BOTH);
     this.getContentPane().setBackground(Color.white);
     
     cConfiguracion config= new cConfiguracion(nColor);
     width= config.getWidth();
     height= config.getHeight();
     ZUL=config.getZUL();
     tipoLetra= config.getTipoLetra();
     
     cImagen imag= new cImagen(width,height);
     
     tit=new JLabel("CREDITOS");
     tit.setBounds(width/4,height/20,width/2,height/9);
     add(tit);
     tit.setHorizontalAlignment(SwingConstants.CENTER);
     tit.setForeground(ZUL);
     tit.setFont(new java.awt.Font(tipoLetra,0,height/16));
  
     
    
     /*ImageIcon cre=new ImageIcon(getClass().getResource("/Imgs/Creditos.jpg"));
     Image c=cre.getImage();
     Image newc=c.getScaledInstance((width-width/20*2),height/8*6,Image.SCALE_SMOOTH);*/
     ImageIcon newCre= imag.obtenerImagenNreduc("/Imgs/Creditos.jpg",(width-width/20*2),height/8*6);
     
    Creditos=new JLabel(newCre);
    Creditos.setBounds(width/20,height/20*3+height/16,(width-width/20*2),height/8*6);
    add(Creditos);
    //imagen de menu que va en el boton menu
     ImageIcon newimg=imag.obtenerImagen("/Imgs/Menu.JPG",8,8);
    
    menu=new JButton(newimg);
    menu.setBounds(width/20,height/20,height/8/2,height/8/2);
    add(menu);
    menu.addActionListener(this);
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(menu)){
         dispose();   
         VMenu w1=new VMenu(ZUL);
        }
    }
    
}
