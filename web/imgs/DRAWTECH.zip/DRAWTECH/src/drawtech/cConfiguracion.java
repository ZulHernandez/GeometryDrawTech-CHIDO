/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawtech;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

/**
 *
 * @author Saul
 */
public class cConfiguracion {
    
    Color ZUL;
    Color SUL;
    String tipoLetra;
    Dimension pantalla;
    String imagProblemas[];
    String descripProblemas;
    
    public cConfiguracion()
    {
        ZUL= new Color(41,103,159);
        SUL= new Color(91,155,213);
        tipoLetra="SHOWCARD GOTHIC";
        pantalla= Toolkit.getDefaultToolkit().getScreenSize();
        imagProblemas= new String [5];
    }
    public cConfiguracion(Color nColor)
    {
        ZUL= nColor;
        SUL= new Color(91,155,213);
        tipoLetra="SHOWCARD GOTHIC";
        pantalla= Toolkit.getDefaultToolkit().getScreenSize();
        imagProblemas= new String [5];
    }
    public Color getZUL() {
        return ZUL;
    }

    public void setZUL(Color ZUL) {
        this.ZUL = ZUL;
    }

    public Color getSUL() {
        return SUL;
    }

    public void setSUL(Color SUL) {
        this.SUL = SUL;
    }

    public String getTipoLetra() {
        return tipoLetra;
    }

    public void setTipoLetra(String tipoLetra) {
        this.tipoLetra = tipoLetra;
    }
    public int  getWidth()
    {
        return (int) pantalla.getWidth();
    }
    public int getHeight()
    {
        return (int) pantalla.getHeight();
    }
    
    public String getDescripcionProblem()
    {
        return descripProblemas;
    }
    
    public String [] getVentanaProblemas(int problema)
    {
        switch(problema)
        {
            case 1:
              
               imagProblemas[0]="/Imgs/PN1.gif";
               imagProblemas[1]="/Imgs/PN2.gif";
               imagProblemas[2]="/Imgs/PN3.gif";
               imagProblemas[3]="/Imgs/PN4.gif";
               imagProblemas[4]="/Imgs/PN5.gif";
               descripProblemas="<html> 1.-Dibuja una circunferencia y traza el diametro del circulo<br><br>2.-Dibuja 2 segmentos de circunferencia del largo  del diametro con centro en un extremo del diametro(Hacer para ambos extremos)<br><br>3.-Divide el diametro en un numero de partes iguales correspondiente al poligono a dibujar<br><br>4.-Trazar rectas uniendo el punto donde se intersectan los segmentos con las divisiones del diametro (Ambos lados)<br><br>5.-Unir los puntos de tangencia de las rectas con la circunferencia ";
               break;
           case 2:
               imagProblemas[0]="/Imgs/E1.gif";
               imagProblemas[1]="/Imgs/E2.gif";
               imagProblemas[2]="/Imgs/E3.gif";
               imagProblemas[3]="/Imgs/E4.gif";
               imagProblemas[4]="/Imgs/EnlacesGif.gif";
               descripProblemas="<html>1.-Tazar una circiunferencia de radio ´r´<br><br>2.-Dibujar dos rectas paralelas 'AB' y 'CD' que esten debajo de la circunferencia<br><br>3.-Abrir el compas sumando las distancias del radio y del radio a la recta inferior  de las paralelas con centro en el radio verificar donde intersecta con la recta superior<br><br> 4.-Dibujar una perpendicular con el punto de intersccion antes realizado hasta la recta inferior<br><br>5.-Abrir el compas con la distancia de la perpendicular antes realizada.Con centro en 'P' unir el otro extremo de la perpendicular con la cicunferencia.";

               break;
           case 3:
               imagProblemas[0]="/Imgs/O1.gif";
               imagProblemas[1]="/Imgs/O2.gif";
               imagProblemas[2]="/Imgs/O3.gif";
               imagProblemas[3]="/Imgs/O4.gif";
               imagProblemas[4]="/Imgs/O5.gif";
               descripProblemas="<html>1. trazar un paralelogramo con angulos de 30 grados (rombo) con la medida de sus lados igual al diametro del circulo<br><br>2. trazar las diagonales del paralelogramo<br><br>3.-3. desde los extremos de la diagonal inferior, prolongar rectas a 60 grados hasta  tocar los limites de la figura, obteniendo asi los puntos 3 y 4 (puntos de interseccion de las rectas prolongadas)<br><br>4. trazar arcos con centro en 1, 2, 3 y 4 tangentes al paralelogramo, uniendo sus extremos entre si.<br><br>5. Listo!!!";
               break;
           case 4:
               imagProblemas[0]="/Imgs/P1.gif";
               imagProblemas[1]="/Imgs/P2.gif";
               imagProblemas[2]="/Imgs/P3.gif";
               imagProblemas[3]="/Imgs/P4.gif";
               imagProblemas[4]="/Imgs/P5.gif";
               descripProblemas="<html>1.-Trazar 2 rectas que coincidan en un punto(trazadas a 90 preferentemente)<br><br>2.-Dividir las rectas en partes n iguales<br><br>3.-Unir el ultimo punto de la recta con el primero de la otra recta<br><br>4.-Hacer lo mismo con los puntos siguientes<br><br>5.-Listo!!!<html> ";

               break;
           case 5:   
               imagProblemas[0]="/Imgs/R1.gif";
               imagProblemas[1]="/Imgs/R2.gif";
               imagProblemas[2]="/Imgs/R3.gif";
               imagProblemas[3]="/Imgs/R4.gif";
               imagProblemas[4]="/Imgs/RectaGif.gif";
               descripProblemas="<html> 1.-Trazar una recta AB<br><br> 2.-trazar una semirecta que parta de cualquier punta de A o B<br><br> 3.- Abrir el compas a cualquier distancia<br><br> 4.-dividir la semirecta en las partes que quieran<br><br> 5.- Hacer perpendiculares desde la semirecta<br><br> 6.- Listo!!!!!<html>";
           break;
               
           default:
               descripProblemas="NO FUNCIONA";
                
        }
        return imagProblemas;
    }
    public String descripProblemaLista(int problema)
    {
        switch(problema)
        {
            case 1:
                descripProblemas="<html>Mediante una circunferencia trazar un<br><br> poligono de 'n' lados inscrito en ella<html>";
            break;
            case 2:
                descripProblemas="<html>Enlazar un segmento de curva con un segmento<br><br> de recta dado mediante un arco y dado un radio<html>";
            break;
            case 3:
                descripProblemas="<html>Trazar una elipse por <br><br>el metodo de los cuatro puntos<html>";
                break;
            case 4:
                descripProblemas="<html>Dadas dos rectas concurrentes<br><br> trazar una parabola<html>";
                break;
            case 5:
                descripProblemas="<html>Dados dos puntos A y B que forman una recta<br><br> dividir esta en 'n' segmentos iguales<html>";
        }   
                
        return descripProblemas;
    }
    
}
