/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawtech;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author Saul
 */
public class cImagen {
    
    int width;
    int height;
    
    public cImagen(int width, int height)
    {
        this.width=width;
        this.height=height;
    }
   
    public ImageIcon obtenerImagen(String url, int reducWidth, int reducHeight)
    {
        ImageIcon i= new ImageIcon(getClass().getResource(url));
        Image i2=i.getImage();
        Image i3=i2.getScaledInstance(width/reducWidth, height/reducHeight,Image.SCALE_SMOOTH);
        ImageIcon i4= new ImageIcon(i3);
        return i4;
    }
    
    public ImageIcon obtenerImagenNreduc(String url, int wid, int heig)
    {
        ImageIcon i= new ImageIcon(getClass().getResource(url));
        Image i2=i.getImage();
        Image i3=i2.getScaledInstance(wid, heig,Image.SCALE_SMOOTH);
        ImageIcon i4= new ImageIcon(i3);
        return i4;
        
    }
    
}
