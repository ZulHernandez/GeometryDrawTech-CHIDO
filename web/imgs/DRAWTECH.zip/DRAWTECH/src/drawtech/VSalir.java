
package drawtech;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class VSalir extends JFrame implements ActionListener{

    JLabel gif;
    JButton  si;
    JButton no;
    JLabel mensaje;
    JLabel  a;
    JLabel b;
    int width;
    int height;
    Color ZUL;
    public VSalir(Color nColor){
    
        setLayout(null);
        setSize(525,600);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.getContentPane().setBackground(Color.WHITE.darker());
      cConfiguracion config= new cConfiguracion(nColor);
      width=config.getWidth();
      height=config.getHeight();
      ZUL=config.getZUL();
      cImagen imag= new cImagen(width,height);
      ImageIcon g=new ImageIcon(getClass().getResource("/Imgs/GifSalir.gif"));
      
     gif=new JLabel(g);
     g.setImageObserver(gif);
     gif.setBounds(50,50,400,300);
     add(gif);
    
     
     mensaje=new JLabel("¿Deseas salir?");
     mensaje.setBounds(50,400,400,50);
     add(mensaje);
     mensaje.setHorizontalAlignment(SwingConstants.CENTER);
     mensaje.setVerticalAlignment(SwingConstants.CENTER);
     mensaje.setForeground(Color.white);
     
     //imagen para el boton de si
     ImageIcon newimg=imag.obtenerImagenNreduc("/Imgs/No.JPG",75,75);
     
     si=new JButton(newimg);
     si.setBounds(50,450,75,75);
     add(si);
     si.addActionListener(this);
     //label con el texto acorde al boton de si
     a=new JLabel("Si");
     a.setBounds(50,425,75,25);
     add(a);
     a.setHorizontalAlignment(SwingConstants.CENTER);
     a.setForeground(Color.white);
     //Imagen del boton no
     ImageIcon newi=imag.obtenerImagenNreduc("/Imgs/Si.jpg",75,75);
     //Label con texto acorde al boton no
     b=new JLabel("No");
     b.setBounds(375,425,75,25);
     add(b);
     b.setHorizontalAlignment(SwingConstants.CENTER);
     b.setForeground(Color.white);
     no=new JButton(newi);
     no.setBounds(375,450,75,75);
     add(no);
     no.addActionListener(this);
        
    }
    
            
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(si)){
           
        Runtime.getRuntime().exit(0);
        }
        if(e.getSource().equals(no)){          
            dispose();
        }
    }
    
    
    
}
