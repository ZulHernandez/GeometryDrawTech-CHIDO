package drawtech;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class vPersonalizacion extends JFrame implements ActionListener {
    JLabel encabezado;
    JLabel muestra;
    JButton estilo1;
    JButton estilo2;
    JButton estilo3;
    JButton estilo4;
    JButton entrar;
    int width;
    int height;
    Color colorGral;
    String tipoLetra;
    
    
    public vPersonalizacion()
    {
        setLayout(null);   
         setSize(1300,700);
         setLocationRelativeTo(null);
         setVisible(true);
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setExtendedState(JFrame.MAXIMIZED_BOTH);
         this.getContentPane().setBackground(Color.white);
         
       cConfiguracion config = new cConfiguracion();
        colorGral=config.getZUL();
        tipoLetra=config.getTipoLetra();   
        width=config.getWidth();
        height=config.getHeight(); 
        
        encabezado=new JLabel("PERSONALIZA LA APARIENCIA ANTES DE ENTRAR");
        encabezado.setBounds(width/100*20,height/100,width/100*60,height/100*20);
        add(encabezado);
        encabezado.setHorizontalAlignment(SwingConstants.CENTER);
        encabezado.setVerticalAlignment(SwingConstants.CENTER);
        encabezado.setFont(new java.awt.Font(tipoLetra, 0,height/25));
        
        muestra=new JLabel();
        muestra.setBounds(width/3*2,height/2,width/8,height/10);
        add(muestra);
        muestra.setOpaque(true);
        muestra.setBackground(colorGral);
        
        entrar=new JButton("Entrar");
        entrar.setBounds(width/3*2,height/4*3,width/8,height/10);
        add(entrar);
        entrar.addActionListener(this);
        entrar.setFont(new java.awt.Font(tipoLetra,0,height/40));
        entrar.setBackground(colorGral);
        entrar.setForeground(Color.white);
        
        
        estilo1=new JButton("Estilo A");
        estilo1.setBounds(width/8,height/16*3,width/4,height/10);
        add(estilo1);
        estilo1.addActionListener(this);
        estilo1.setFont(new java.awt.Font(tipoLetra,0,height/20));
        estilo1.setBackground(Color.black);
        estilo1.setForeground(Color.white);
        
        estilo2=new JButton("Estilo B");
        estilo2.setBounds(width/8,height/16*6,width/4,height/10);
        add(estilo2);
        estilo2.addActionListener(this);
        estilo2.setFont(new java.awt.Font(tipoLetra,0,height/20));
        estilo2.setBackground(Color.red);
        estilo2.setForeground(Color.white);
        
        estilo3=new JButton("Estilo C");
        estilo3.setBounds(width/8,height/16*9,width/4,height/10);
        add(estilo3);
        estilo3.addActionListener(this);
        estilo3.setFont(new java.awt.Font(tipoLetra,0,height/20));
        estilo3.setBackground(Color.ORANGE);
        estilo3.setForeground(Color.white);
        
        estilo4=new JButton("Estilo predeterminado");
        estilo4.setBounds(width/8,height/16*12,width/4,height/10);
        add(estilo4);
        estilo4.addActionListener(this);
        estilo4.setFont(new java.awt.Font(tipoLetra,0,height/20));
        estilo4.setBackground(colorGral);
        estilo4.setForeground(Color.white);
        System.out.println(colorGral);
        
        
         
         
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getActionCommand().equals("Estilo A")){
            muestra.setBackground(estilo1.getBackground());
        }
        else
        {
            if(e.getActionCommand().equals("Estilo B")){
                muestra.setBackground(estilo2.getBackground());
            }
            else
            {
                if(e.getActionCommand().equals("Estilo C")){
                    muestra.setBackground(estilo3.getBackground());
                }
                else
                    if(e.getActionCommand().equals("Estilo predeterminado")){
                        muestra.setBackground(estilo4.getBackground());
                    }
            }
        }
        if(e.getActionCommand().equals("Entrar"))
        {
            int i=JOptionPane.showConfirmDialog(null, "¿Quiere ese color?", "Confirmar color", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(i==0)
            {
                dispose();
                VMenu menu1= new VMenu(muestra.getBackground());
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
    private Color color;
    private JButton botonCambiarColor;
    private Container contenedor;

    //contructor
     public vPersonalizacion()
     {
      super("Mostrar VCambiar Color");

      //al contenedor le asignamos un layout
      contenedor=getContentPane();
      contenedor.setLayout(new FlowLayout());

      botonCambiarColor=new JButton("Cambiar Color");
      botonCambiarColor.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent evento)
       {
        color=JColorChooser.showDialog(vPersonalizacion.this,"seleccione un color", color);

        //indicar color predeterminado si no se selecciona nungun color
        if(color==null)
         color=color.LIGHT_GRAY;
        //cambiar el color al color seleccionado
        contenedor.setBackground(color);

       }
      }
      );
      add(botonCambiarColor);
      setSize(400,300);
      setVisible(true);

     }
     public static void main(String[] arg)
     {
      JFrame.setDefaultLookAndFeelDecorated(true);
      JDialog.setDefaultLookAndFeelDecorated(true);
      vPersonalizacion color=new vPersonalizacion();
      color.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     }*/
    
}
