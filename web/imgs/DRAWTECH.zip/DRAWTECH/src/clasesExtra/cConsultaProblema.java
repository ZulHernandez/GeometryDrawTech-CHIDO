/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clasesExtra;

import java.sql.ResultSet;

/**
 *
 * @author Saul
 */
public class cConsultaProblema {
    
    String _Error;
    
    public cConsultaProblema()
    {
        _Error="";
    }

    public String getError() {
        return _Error;
    }
    
    public int traerConsultas(int ide)
    {
        int visitas=0;
        ResultSet rsConsult= null;
        BD.cDatos sql= new BD.cDatos("root","n0m3l0","jdbc:mysql://localhost:3306/GDLocal","com.mysql.jdbc.Driver");
        try
        {
            sql.conectar();
           rsConsult= sql.consulta("call sp_TraeConsultas("+ide+");");
           if(rsConsult.next())
           {
               visitas=Integer.parseInt(rsConsult.getString("Visitas"));
           }
           sql.cierraConexion();
        }
        catch(Exception e)
        {
            _Error=e.getMessage();
        }
        return visitas;
    }
    
    public String aumentaConsulta(int ide)
    {
       String estado="";
        ResultSet rsAumenta=null;
        BD.cDatos sql=new BD.cDatos("root","n0m3l0","jdbc:mysql://localhost:3306/GDLocal","com.mysql.jdbc.Driver");
        try
        {
            sql.conectar();
            rsAumenta=sql.consulta("call sp_AgregaConsulta("+ide+");");
            if(rsAumenta.next())
            {
                estado=rsAumenta.getString("Regreso");
            }
            sql.cierraConexion();
        }
        catch(Exception e)
        {
            _Error=e.getMessage();
        }
        return estado;
    }
    
}
